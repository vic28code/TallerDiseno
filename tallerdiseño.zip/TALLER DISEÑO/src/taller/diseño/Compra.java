/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller.diseño;

import java.util.List;

/**
 *
 * @author CltControl
 */
public class Compra {
    private Pago pago;
    private PagoPayPal pagoPaypal;
    private List articulos;
    
    public Compra(Pago pago){
        
    }
    public void agregarArticulo(Articulo articulo){
        
    }
    public void removerArticulo(Articulo articulo){
        
    }
}
