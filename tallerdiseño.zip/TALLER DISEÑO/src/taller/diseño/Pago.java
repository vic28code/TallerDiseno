/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller.diseño;

/**
 *
 * @author CltControl
 */
public class Pago {
    
    public void realizarCobro(double monto){
        
    }
    public void calcularImpuestosFactura(){
        
    }
    public void generarFactura(){
        
    }
}
